# steppingStone v1.0
A pipeline for identification of chromothripsis breakpoints and cancer rearrangements

### Download and Compile:

    $ git clone  https://github.com/wtsi-hpag/steppingStone.git 
    $ cd steppingStone 
    $ bash install.sh
		
If everything compiled successfully you must see the final comment: 
		"Congrats: installation successful!"		

#### External packages
The genome aligner BWA (http://bio-bwa.sourceforge.net) and SMALT (http://www.sanger.ac.uk/science/tools/smalt-0) are downloaded and compiled by steppingStone.

### Run the pipelines

           $ /full/path/to/steppingStone/src/steppingStone -nodes <nodes>  \
                 -reads /lustre/team117/zn1/project/cancer/PacBio-HiFi-sample.fastq.gz \
                 reference.fasta breakpoints.dat  

       Note: "-reads " expects a full path or a file in the working directory.

